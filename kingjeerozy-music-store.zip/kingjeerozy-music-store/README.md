# Kingjeerozy Music Store

A Next.js + Supabase + Paystack digital music store for selling songs before unlocking full playback/download.

## Architecture
- Next.js App Router: storefront and server-side payment routes.
- Supabase Postgres: songs and orders.
- Supabase Storage: private `music` bucket containing original MP3s.
- Paystack: NGN checkout, verification and webhook fulfillment.

## Setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Create a Supabase project and run `supabase/schema.sql` in SQL Editor.
4. Create a **private** Storage bucket named `music` and upload your MP3 under the exact `file_path` stored in `songs`.
5. Copy `.env.example` to `.env.local` and add credentials.
6. Run `npm run dev`.
7. In Paystack, set the webhook URL to `/api/payments/webhook` on your deployed domain.

## Payment flow
1. Customer enters email and clicks Buy.
2. Server reads the song price from Postgres and initializes Paystack.
3. Customer pays.
4. Paystack webhook marks the order paid after signature + amount checks.
5. A paid purchase can receive a short-lived signed Storage URL for playback/download.

## Production hardening still required
- Add Supabase Auth and middleware protecting `/admin`.
- Replace the email + song ID library form with authenticated user accounts and a purchased-library table keyed to user ID.
- Add rate limiting and abuse protection to unlock routes.
- Add proper cover image upload/admin forms.
- Add refund handling and reconciliation.
- Add legal pages: Terms, Privacy, Refund Policy.
- Test Paystack in test mode, then switch to live keys.
