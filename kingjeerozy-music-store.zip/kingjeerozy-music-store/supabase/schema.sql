create extension if not exists pgcrypto;
create table if not exists public.songs (
 id uuid primary key default gen_random_uuid(), title text not null, slug text unique not null, artist text default 'Kingjeerozy', description text, price_naira numeric(12,2) not null default 1000, cover_url text, preview_url text, file_path text not null, published boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), reference text unique not null, email text not null, song_id uuid not null references public.songs(id) on delete restrict, amount_naira numeric(12,2) not null, status text not null default 'pending' check(status in ('pending','paid','failed','refunded')), paystack_transaction_id text, paid_at timestamptz, created_at timestamptz not null default now()
);
create index if not exists orders_email_idx on public.orders(lower(email));
create index if not exists orders_song_idx on public.orders(song_id);
alter table public.songs enable row level security; alter table public.orders enable row level security;
create policy "published songs are public" on public.songs for select using (published=true);
-- Keep orders inaccessible to the browser; server routes use the service role.
insert into public.songs(title,slug,artist,description,price_naira,file_path,published) values ('Lion Dance','lion-dance','Kingjeerozy','Official Kingjeerozy release.','2000','kingjeerozy/lion-dance.mp3',false) on conflict (slug) do nothing;
