export async function paystackInitialize(email:string,amountKobo:number,reference:string,songId:string){
 const r=await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({email,amount:amountKobo,currency:'NGN',reference,callback_url:`${process.env.NEXT_PUBLIC_SITE_URL}/library`,metadata:{song_id:songId}})});
 const data=await r.json(); if(!r.ok||!data.status) throw new Error(data.message||'Payment initialization failed'); return data.data;
}
export async function paystackVerify(reference:string){
 const r=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`},cache:'no-store'}); const data=await r.json(); if(!r.ok||!data.status) throw new Error(data.message||'Payment verification failed'); return data.data;
}
