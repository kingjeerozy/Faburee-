import './globals.css';
export const metadata={title:'Kingjeerozy Music Store',description:'Official music store of Kingjeerozy'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
